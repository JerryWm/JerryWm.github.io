
const CFG_PATH = "config.json";

const NONCE_WORKER_DELTA = 1e5;

const TIMEINTERVAL_SHOW_STAT = 1e3 * 60 * 5;

process.on('uncaughtException', function(e) {});

class Logger {
	constructor(printer, prefix) {
		this.printer = printer;
		this.prefix = prefix || "";
		this.noPrint = false;
	}

	dev(text) { this.log(Logger.LOG_COLOR_SR + "[DEV] " + text) }

	success(text) { this.log(Logger.LOG_COLOR_GREEN + "[SUCCESS] " + text) }
	notice(text)  { this.log(Logger.LOG_COLOR_SR + "[NOTICE] " + text) }
	warning(text) { this.log(Logger.LOG_COLOR_YELLOW + "[WARNING] " + text) }
	error(text)   { this.log(Logger.LOG_COLOR_RED + "[ERROR] " + text) }

	log(text) {
		text += Logger.LOG_COLOR_RESET;
		
		if ( this.noPrint ) {
			return;
		}
		
		text = `[${this.prefix}] ${text}`;
		
		if ( this.printer instanceof Logger ) {
			this.printer.log(text);
		} else {
			this.printer(text);
		}
	}
	
	close() {
		this.noPrint = true;
	}
}
Logger.LOG_COLOR_RESET   = "\033[0m";
Logger.LOG_COLOR_SR	     = "\033[1;30m";
Logger.LOG_COLOR_RED     = "\033[1;31m";
Logger.LOG_COLOR_GREEN   = "\033[1;32m";
Logger.LOG_COLOR_YELLOW  = "\033[1;33m";
Logger.LOG_COLOR_BLUE    = "\033[1;34m";
Logger.LOG_COLOR_WHITE   = "\033[1;37m";
Logger.LOG_COLOR_DEVMODE = "\033[1;35m";
Logger.LOG_COLOR_MAGENTA = "\033[1;35m";
Logger.LOG_COLOR_CYAN    = "\033[1;36m";

Logger.LOG_COLOR_MAGENTA_LIGHT = "\033[0;35m";
Logger.LOG_COLOR_GREEN_LIGHT   = "\033[0;32m";


class Common {	
}
Common.revers2b = function(s) {
	let _s = "";
	for(let i = 0; i < s.length; i+=2) {
		_s = s.substr(i, 2) + _s;
	}
	return _s;
}
Common.parseIntByHex = function(hex) {
	return parseInt(Common.revers2b(hex), 16);
}
Common.strToHashSimplie = function(s) {
	let r = "";
	for(let i = 0; i < s.length; i++) {
		r += "_" + s.charCodeAt(i).toString(16);
	}
	return r;
}

class StratumProxy {
	constructor(options, logger) {
		this.logger = new Logger(logger, "STRATUM-PROXY");
		
		this.options = options;
		
		[this.pool_host  , this.pool_port  ] = this.addressEx(this.options.pool_address);

		[this.server_host, this.server_port] = this.addressEx(this.options.server_address);
		
		this.stratumClient = null;
		this.stratumServer = null;

		this.worker_seq = 0;
		
		this.job = null;
		
		this._jobs = {};
		
		this.serverFrame();
		
		this.clientFrame();
		
		setInterval(() => {
			if ( this.stratumServer ) {
				this.stratumServer.showStat();
			}
		}, TIMEINTERVAL_SHOW_STAT);
	}

	serverFrame() {
		this.stratumServer = new StratumServer(
			this.server_host, 
			this.server_port, 
			this.getJobForWorker.bind(this), 
			this.submitJob.bind(this), 
			() => setTimeout(this.serverFrame.bind(this), 1e3), 
			this.logger
		);
	}
	
	clientFrame() {
		this.logger.notice("Pool address   > " + Logger.LOG_COLOR_MAGENTA + this.pool_host + ":" + this.pool_port);
		this.logger.notice("Pool password  > " + Logger.LOG_COLOR_MAGENTA + this.options.pool_password);
		this.logger.notice("Wallet address > " + Logger.LOG_COLOR_MAGENTA + this.options.wallet_address);

		this.stratumClient = new StratumClient(
			this.pool_host, 
			this.pool_port, 
			this.options.pool_password, 
			this.options.wallet_address, 
			this.setJob.bind(this), 
			() => setTimeout(this.clientFrame.bind(this), 1e3),
			this.logger
		);
	}
	
	addressEx(address) {
		let m;
		if ( !(m = address.match(/([^\\/]*?)\s*\:\s*(\d+)/)) ) {
			this.logger.error("Change you config. Address is invalid")
			throw 0;
		}
		
		return [m[1], m[2]];
	}
	
	setJob(job) {
		this._jobs = {};
		
		this.job = job;
		
		this.worker_seq = 0;
		
		if ( this.stratumServer ) {
			this.stratumServer.updateJob();
		}
	}
	getJobForWorker() {
		if ( !this.job ) {
			return null;
		}
		
		let seq = this.worker_seq++;

		let copyJob = {
			job_id: this.job.job_id,
			target: this.job.target,
			blob: this.job.blob,
		};
		
		if ( !this.options.emu_nicehash ) {
			let nonceInt = Common.parseIntByHex(copyJob.blob.substr(39*2, 6)) | 0;

			nonceInt = (nonceInt + seq * NONCE_WORKER_DELTA) & 0xFFFFFF;
			
			let nonceHex = Common.revers2b("000000" + nonceInt.toString(16)).substr(0, 6);

			copyJob.blob = copyJob.blob.substr(0, 39*2) + nonceHex + copyJob.blob.substr(39*2 + 6);
		} else {
			let __offset_byte = 39*2 + 2*3;
	
			let _byteInt = parseInt(copyJob.blob.substr(__offset_byte, 2), 16)|0;
			let _byteHex = ("00" + (_byteInt + seq).toString(16)).slice(-2);
			
			copyJob.blob = copyJob.blob.substr(0, __offset_byte) + _byteHex + copyJob.blob.substr(__offset_byte + 2);
			
			//this.logger.dev("Emu nicehash start nonce: " + copyJob.blob.substr(39*2, 8));
		}

		this.logger.dev("Start hex-nonce for worker [seq: " + seq + "] "+copyJob.blob.substr(39*2, 8));
		
		return copyJob;
	}
	
	tryResultJob(job_id, nonce) {
		let _job_id = "__" + Common.strToHashSimplie(job_id);
		let _job_nonce = "__" + Common.strToHashSimplie(nonce);

		this._jobs = this._jobs || {};
		
		this._jobs[_job_id] = this._jobs[_job_id] || {};

		if ( this._jobs[_job_id][ _job_nonce ] ) {
			this.logger.warning("The worker sent a duplicate of work");
			return false;
		}
		
		this._jobs[_job_id][ _job_nonce ] = true;
		
		return true;
	}
	
	submitJob(job) {
		if ( this.stratumClient ) {
			if ( this.tryResultJob(job.job_id, job.nonce) ) {
				this.stratumClient.submitJob({
					job_id: job.job_id,
					nonce: job.nonce,
					result: job.result,
				});
			}
		}
	}
}

class StratumRecv {
	constructor() {
		this.incoming_buf = "";
	}
	
	recv(buf, onRecvObj) {
		this.incoming_buf += buf.toString();

		try {
			this.incoming_buf = this.incoming_buf.replace(/[^\r\n]*[\r\n]/g, (m) => {
				m = m.trim();
				if ( m.length ) {
					onRecvObj(JSON.parse(m));
				}
				return "";
			});
		} catch(e) {
			this.incoming_buf = "";
			return false;
		}

		return true;
	}
}
class StratumServer {
	constructor(host, port, cbGetJob, cbSetResultJob, cbClose, logger) {
		this.logger = new Logger(logger, "STRATUM-SERVER-LISTENING");
		
		this.cbGetJob = cbGetJob;
		this.cbSetResultJob = cbSetResultJob;
		this.cbClose = cbClose;

		this.socket = require('net').createServer(this.onClient.bind(this));
		
		this.job = null;
		this.workerNextId = 0;
		this.workerList = Object.create(null);
		
		this.host = host;
		this.port = port;
		
		this.setEvents();
	}
	
	setEvents() {
		this.socket.on("error", (e) => {
			this.logger.error('An error has occurred ' + (e.code ? e.code : ""));
			this.close();
		});
		
		this.socket.on("listening", () => {
			this.logger.success("Opened server on \""+this.host+':'+this.port+'"' );
		});

		try {
			this.logger.notice("Attempting opened server on "+Logger.LOG_COLOR_MAGENTA_LIGHT+"\""+this.host+':'+this.port+'"');
			this.socket.listen(this.port, this.host);
		} catch(e) {
			this.logger.error('An error has occurred ' + (e.message ? e.message : ""));
			this.close();
		}
	}
	
	close() {
		let list = [];
		for(let i in this.workerList) { list.push(this.workerList[i]); }
		for(let i in list) { list[i].close(); }
		
		this.socket.close();
		this.logger.close();
		this.cbClose();

		this.cbGetJob = (()=>null);
		this.cbSetResultJob = (()=>null);
		this.cbClose = (()=>null);
	}

	onClient(socket) {
		let workerId = this.workerNextId++;
		
		this.workerList[workerId] = new StratumServerClient(socket, workerId, this.cbGetJob, (resultJob) => {
			this.resultJobPrepare(this.workerList[workerId], resultJob);
		}, () => {
			delete this.workerList[workerId];
		}, this.logger);
	}

	resultJobPrepare(worker, job) {
		this.cbSetResultJob(job);
	}

	updateJob() {
		for(let i in this.workerList) {
			this.workerList[i].updateJob();
		}
	}

	showStat() {
		this.logger.notice("Workers count: " + Object.keys(this.workerList).length);
		for(let i in this.workerList) {
			this.workerList[i].logger.notice("Agent: " + this.workerList[i].agent.substr(0, 32) + "...");
		}
	}
}
class StratumServerClient {
	constructor(socket, id, cbGetJob, cbSetResultJob, cbClose, logger) {
		this.id = id;
		this.wid = "wid" + this.id;
		
		this.logger = new Logger(logger, "WORKER #"+this.id+"");

		this.cbGetJob = cbGetJob;
		this.cbSetResultJob = cbSetResultJob;
		this.cbClose = cbClose;
		
		this.socket = socket;
		
		this.incoming = new StratumRecv();

		this.pool_password = "";
		this.user_wallet   = "";
		
		this.state = StratumServerClient.STATE_NO_LOGIN;
		
		this.isSendJob = false;
		
		this.logger.notice(`Accepted worker`);
		
		this.agent = "";
		
		this.setEvents();
	}
	
	setEvents() {
		
		this.socket.on('data', (data) => { 
			if ( !this.incoming.recv(data, this.recvFrameObject.bind(this)) ) {
				this.sendError("Bad json");
				this.logger.error("Worker send bad json");
				this.close();
			}
		});
		
		this.socket.on('end', () => {
			this.logger.notice('Client disconnected'); 
			this.close();
		});
		
		this.socket.on('error', () => {
			this.logger.error('Error socket');
			this.close();
		});
		
		this.socket.on('timeout', () => {
			this.logger.error('Error socket timeout');
			this.close();
		});
		
	}

	close() {
		this.socket.end();
		this.logger.notice("Disconnected...");
		this.logger.close();
		this.cbClose();

		this.cbGetJob = (()=>null);
		this.cbSetResultJob = (()=>null);
		this.cbClose = (()=>null);
	}
	
	recvFrameObject(obj) {
		if ( !obj ) {
			this.notice("Worker send bad data");
			return;
		}
		
		let resultId = parseInt(obj.id);
		
		if ( this.state === StratumServerClient.STATE_NO_LOGIN ) {
			
			if ( obj.method !== 'login' ) {
				this.sendResult(resultId, null, "Expected client login method");
				this.logger.error("Send error: Expected client login method");
				this.close();
				return;
			}
		
			if ( obj.params ) {
				this.user_wallet   = obj.params.login;
				this.pool_password = obj.params.pass;
				this.agent         = obj.params.agent;
			}
			
			let job = this.cbGetJob();
			if ( !job ) {
				this.sendResult(resultId, null, "Proxy server is not ready");
				this.logger.error("Send error: Proxy server is not ready");
				this.close();
				return;
			}

			this.sendResult(resultId, {
				id: this.wid,
				job: job,
				status: "OK"
			});
			
			this.state = StratumServerClient.STATE_NORMAL;
			
			let agent = (this.agent || "").substr(0, 16) + "...";
			this.logger.success(`${this.socket.address().address}:${this.socket.address().port} / ${agent}`);

			return;
			
		}
		
		if ( !obj.method ) {
			return;
		}
		
		switch(obj.method) {
			case "submit":
				this.sendResult(resultId, {status: "OK"});
				
				if ( !obj.params ) {
					this.logger.warning("Worker send invalid message[method=submit]");
					break;
				}

				if ( !obj.params.job_id ) {
					this.logger.warning("Worker send invalid message[method=submit, invalid job_id]");
					break;
				}
				
				if ( !obj.params.nonce || obj.params.nonce.length !== 8 ) {
					this.logger.warning("Worker send invalid message[method=submit, invalid nonce]");
					break;
				}
				
				if ( !obj.params.result || obj.params.result.length !== 64 ) {
					this.logger.warning("Worker send invalid message[method=submit, invalid result]");
					break;
				}
				
				this.logger.notice(`Result job [nonce: ${obj.params.nonce}]`);
				this.cbSetResultJob(obj.params);
				break;
				
			case "keepalived":
				this.sendResult(resultId, {status: "KEEPALIVED"});
				break;
		}
		
	}

	makeErrorForSend(errorText, errorCode) {
		let error = null;
		
		if ( errorText !== undefined ) {
			if ( errorCode === undefined ) {
				errorCode = -1;
			}
			
			error = {
				code: errorCode,
				message: errorText,
			};
		}

		return error;
	}
	sendResult(id, result, errorText, errorCode) {
		this.sendObj({
			id: id,
			result: result,
			error: this.makeErrorForSend(errorText, errorCode),
		});
	}
	sendJob(job) {
		let obj = {
			error: null,
			method: "job",
			params: job,
		};
		this.sendObj(obj);
	}
	sendError(errorText, errorCode) {
		obj = {
			error: this.makeErrorForSend(errorText, errorCode),
		};
		this.sendObj(obj);
	}
	sendObj(obj, cb) {
		obj.jsonrpc = "2.0";
		if ( !obj.error ) {
			obj.error = null;
		}

		//this.logger.dev('send: '+JSON.stringify(obj) + "\n");
		this.socket.write(JSON.stringify(obj) + "\n", cb);
	}
	
	
	updateJob() {
		let job = this.cbGetJob();
		if ( job ) {
			this.sendJob(job);
		}
	}
	
}
StratumServerClient.STATE_NO_LOGIN = 1;
StratumServerClient.STATE_NORMAL = 2;

class StratumClient {
	constructor(pool_host, pool_port, pool_password, user_wallet, onAcceptJob, onDisconnect, logger) {
		this.pool_host     = pool_host;
		this.pool_port     = pool_port;
		this.pool_password = pool_password;
		this.user_wallet   = user_wallet;
		
		this.onAcceptJob   = onAcceptJob || (() => {});

		this.logger = new Logger(logger, "STRATUM-CLIENT");
		
		this.incoming = new StratumRecv();
		
		this.socket = null;
		
		this.onAcceptJob = onAcceptJob;
		this.onDisconnect = onDisconnect;
		
		this.USER_AGENT = "JerryPROXY-STRATUM~XMR";
		
		this.job = null;
		
		this.no_login = true;
		
		this.connected = false;
		this.disconnected = false;
		this.isClose = false;
		
		this.target = null;
		
		this.connect();
	}

	connect() {
		this.logger.notice("Attempting to connect to "+Logger.LOG_COLOR_MAGENTA_LIGHT+"\""+this.pool_host+':'+this.pool_port+'"');
		this.socket = require('net').createConnection({
			host: this.pool_host,
			port: this.pool_port,
		});
		
		this.setEvents();
	}
	
	disconnect() {
		if ( this.socket ) {
			this.socket.end();
			this.socket = null;
			this.onDisconnect();
		}
		
		this.connected = false;
		this.disconnected = true;
		this.isClose = true;
	}
	
	setEvents() {
		this.socket.on('connect', () => {
			this.connected = true;
			
			this.logger.success('Connected to "'+this.pool_host+':'+this.pool_port+'"');

			this.sendObj({
				id: 1,
				method: "login",
				params: {
					agent: this.USER_AGENT,
					login: this.user_wallet,
					pass : this.pool_password,
				}, 
			});
		});
		
		this.socket.on('data', (data) => {
			if ( !this.incoming.recv(data, this.recvFrameObject.bind(this)) ) {
				this.logErrorClSv("Client send bad json");
				this.disconnect();
			}
		});
		
		this.socket.on('end', () => {
			this.logger.error('The server disconnected the connection');
			this.disconnect();
		});
		
		this.socket.on('error', (e) => {
			this.logger.error('An error has occurred ' + (e.code ? e.code : ""));
			this.disconnect();
		});
		
		this.socket.on('timeout', () => {
			this.logger.error('Timeout error');
			this.disconnect();
		});
	}
	
	sendObj(obj) {
		this.socket.write( JSON.stringify(obj) + '\n' );
	}
	
	recvFrameObject(obj) {
		if ( this.no_login ) {
			if ( obj.error ) {
				this.logger.error('Poole sent a bug "'+(obj.error.message?obj.error.message:'')+'"');
				this.disconnect();
				return;
			}			
			
			if ( obj.result ) {
				if ( !this._checkParamString(obj.result.id, 1, 256) ) {
					this.logger.error('The pool sent the wrong ID format');
					this.disconnect();
					return;
				}
				
				this.id = obj.result.id;	
				this.parseJob(obj.result.job);
			} else {
				this.logger.error('Poole sent a invalid message');
				this.disconnect();
			}
			
			this.no_login = false;
		}
	
		if ( obj.error ) {
			if ( obj.error.message ) {
				this.logger.warning('Poole sent a bug "'+obj.error.message+'"');
			} else {
				this.logger.warning('Poole sent a bug');
			}
			return;
		}
		
		if ( obj.method ) {
			switch(obj.method) {
				case "job":
					this.parseJob(obj.params);
					return;
					break;
			}
		}
		
		if ( obj.result ) {
			if ( obj.result.status.length ) {
				this.logger.notice(Logger.LOG_COLOR_GREEN_LIGHT + "Pool has sent the status \""+ obj.result.status + "\"");
			}
		}		
	}
	
	parseJob(job) {
		if ( !job ) {
			this.logger.error('The pool sent the wrong JOB format');
			this.disconnect();
			return;
		}
		
		if ( !this._checkParamString(job.job_id, 1, 256) ) {
			this.logger.error('The pool sent the wrong JOB_ID format');
			this.disconnect();
			return;
		}
		
		if ( !this._checkParamString(job.blob, 76*2, 76*2) ) {
			this.logger.error('The pool sent the wrong JOB_BLOB format');
			this.disconnect();
			return;
		}
		
		if ( !this._checkParamString(job.target, 4*2, 4*2) ) {
			this.logger.error('The pool sent the wrong JOB_TARGET format');
			this.disconnect();
			return;
		}
		
		this.job = job;
		this.job.is_new = true;

		let target = Common.parseIntByHex(job.target);
		
		let difficulty = (0xFFFFFFFF / target);
		
		this.logger.notice(Logger.LOG_COLOR_GREEN_LIGHT + "Accepted new job #" + this.jobIdToLog(job.job_id) + " difficulty " + difficulty.toFixed(2))
		
		if ( this.target !== target ) {
			this.target = target;
			this.logger.warning("Set difficulty to " + Logger.LOG_COLOR_MAGENTA + difficulty.toFixed(2))
		}
		
		this.onAcceptJob(this.job);
	}
	
	submitJob(job) {
		if ( this.job && (job.job_id === this.job.job_id) ) {
			this.sendObj({
				id: 1,
				method: "submit",
				params: {
					id: this.id,
					job_id: job.job_id,
					nonce:  job.nonce,
					result: job.result,
				}
			});

			this.logger.notice(Logger.LOG_COLOR_GREEN_LIGHT + "Submit result job #" + this.jobIdToLog(job.job_id) + " nonce " + job.nonce);
		}
	}
	
	_checkParamString(s, minlen, maxlen) {
		return ( (typeof(s) === "string") && (s.length >= minlen) && (s.length <= maxlen) );
	}

	
	jobIdToLog(id) {
		const MAXLEN = 32;
		
		if ( id.length <= MAXLEN ) {
			return id;
		}
		
		return id.slice(0, MAXLEN>>1) + "..." + id.slice(-(MAXLEN>>1));
	}
	
}

function getConfig(logger, path) {
	let config = null;
	
	try {
		let file = require('fs').readFileSync(path, 'utf8');
		
		eval('var _cfg = ' + file);

		config = _cfg;
	} catch(e) {
		config = null;
		logger.error("Config \"" + path + "\" not found, or config file invalid json");
	}
	
	return config;
}

function main(logger) {
	let cfg = getConfig(logger, CFG_PATH);
	
	if ( !cfg ) {
		setTimeout(() => main(logger), 5e3);
		return;
	}

	new StratumProxy(cfg, logger);
}

main(
	new Logger((log) => {
		let d = new Date();
		console.log(`[${d.toLocaleDateString()} ${d.toLocaleTimeString()}] ${log}`);
	}, "APP")
);

